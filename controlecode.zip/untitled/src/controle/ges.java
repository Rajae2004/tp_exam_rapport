package controle;

public interface ges<T> {
    void ajouter(T element);
    void supprimer(String identifiant);
    void afficher();
}

