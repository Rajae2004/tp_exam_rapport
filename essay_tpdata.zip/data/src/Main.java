public class Main {

    public static void main(String[] args) {
        String filePath = "data.txt";  // Chemin vers le fichier de données

        // Création des instances
        DataIngestion dataIngestion = new DataIngestion();
        DataDisplay dataDisplay = new DataDisplay();

        // Lecture des données
        dataIngestion.readData(filePath);

        // Affichage des données
        dataDisplay.displayData(dataIngestion.getDataList());
    }
}




