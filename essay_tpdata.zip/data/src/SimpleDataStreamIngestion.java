

import java.util.Scanner;

public class SimpleDataStreamIngestion {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez des données (tapez 'exit' pour arrêter) :");

        while (true) {
            // Lire les données en continu depuis la console
            String inputData = scanner.nextLine();

            // Arrêter le flux si l'utilisateur tape "exit"
            if ("exit".equalsIgnoreCase(inputData)) {
                System.out.println("Arrêt du flux de données.");
                break;
            }

            // Traiter les données entrantes (par exemple, les afficher)
            processData(inputData);
        }

        scanner.close();
    }

    // Méthode simple pour simuler le traitement des données
    private static void processData(String data) {
        System.out.println("Données traitées : " + data);
        // Ajoutez ici d'autres traitements si nécessaire
    }
}
