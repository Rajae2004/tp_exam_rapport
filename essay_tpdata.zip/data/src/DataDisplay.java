import java.util.List;

public class DataDisplay {

    public void displayData(List<String> dataList) {
        System.out.println("Affichage des données :");
        for (String data : dataList) {
            System.out.println(data);
        }
    }
}

