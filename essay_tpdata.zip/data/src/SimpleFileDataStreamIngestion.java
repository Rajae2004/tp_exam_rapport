import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SimpleFileDataStreamIngestion {

    public static void main(String[] args) {
        System.out.println("Début de l'ingestion de données...");

        String filePath = "data.txt";  // Mets le chemin complet si nécessaire

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                processData(line);
                Thread.sleep(1000); // 1 seconde de délai pour simuler le streaming
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Erreur lors de la lecture du fichier ou de l'exécution : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processData(String data) {
        System.out.println("Données traitées : " + data);
    }
}
