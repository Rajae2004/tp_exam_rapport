import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataIngestion {
    private List<String> dataList;

    public DataIngestion() {
        this.dataList = new ArrayList<>();
    }

    // Méthode pour lire les données depuis le fichier
    public void readData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                dataList.add(line);  // Ajouter chaque ligne dans la liste
            }
        } catch (IOException e) {
            System.err.println("Erreur de lecture du fichier : " + e.getMessage());
        }
    }

    // Méthode pour retourner les données lues
    public List<String> getDataList() {
        return dataList;
    }
}
