import java.io.FileWriter;
import java.io.IOException;

public class WriteToFileExample {

    public static void main(String[] args) {
        String filePath = "data.txt";  // Assure-toi que ce chemin est correct
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write("Client1,2023-10-01,100.50\n");
            writer.write("Client2,2023-10-02,250.75\n");
            writer.write("Client3,2023-10-03,80.00\n");
            System.out.println("Données écrites dans le fichier avec succès.");
        } catch (IOException e) {
            System.err.println("Erreur d'écriture dans le fichier : " + e.getMessage());
        }
    }
}
