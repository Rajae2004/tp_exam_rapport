import vehi.GestionParc;
import vehi.Vehicule;
import vehi.Client;

public class Main {
    public static void main(String[] args) {

        GestionParc gestionParc = new GestionParc();

        Vehicule v1 = new Vehicule(1, "BMW", 400);
        Vehicule v2 = new Vehicule(2, "Mustang", 270);
        Vehicule v3 = new Vehicule(3, "Ferrari", 300);


        gestionParc.ajouterVehicule(v1);
        gestionParc.ajouterVehicule(v2);
        gestionParc.ajouterVehicule(v3);


        Client c1 = new Client(1, "Khadija");
        Client c2 = new Client(2, "Rajae");

        gestionParc.ajouterClient(c1);
        gestionParc.ajouterClient(c2);


        gestionParc.afficherVehiculesDisponibles();
        System.out.println();

        gestionParc.affecterVehiculeAClient(c1, 1);
        gestionParc.affecterVehiculeAClient(c2, 1);
        gestionParc.affecterVehiculeAClient(c2, 2);
        System.out.println();


        gestionParc.afficherVehiculesDisponibles();
        System.out.println();


        gestionParc.afficherClients();
        System.out.println();


        gestionParc.retournerVehicule(c1);
        gestionParc.retournerVehicule(c2);
        System.out.println();


        gestionParc.afficherVehiculesDisponibles();
        System.out.println();


        gestionParc.afficherClients();
    }
}

