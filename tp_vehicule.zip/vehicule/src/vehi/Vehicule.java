package vehi;

public class Vehicule {
    private int id;
    private String modele;
    private int autonomieBatterie; // Correction du nom
    private boolean estDisponible;

    public Vehicule(int id, String modele, int autonomieBatterie) {
        this.id = id;
        this.modele = modele;
        this.autonomieBatterie = autonomieBatterie; // Correction du nom
        this.estDisponible = true;
    }

    public int getId() {
        return id;
    }

    public String getModele() {
        return modele;
    }

    public int getAutonomieBatterie() {
        return autonomieBatterie; // Correction du nom
    }

    public boolean isDisponible() {
        return estDisponible;
    }

    public void setDisponible(boolean estDisponible) {
        this.estDisponible = estDisponible;
    }

    public String toString() {
        return "Vehicule{" +
                "id=" + id +
                ", modele='" + modele + '\'' +
                ", autonomieBatterie=" + autonomieBatterie +
                ", estDisponible=" + estDisponible +
                '}';
    }
}

