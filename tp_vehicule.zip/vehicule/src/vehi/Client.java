package vehi;

public class Client {
        private int id;
        private String nom;
        private Vehicule vehiculeLoue;


        public Client(int id, String nom) {
            this.id = id;
            this.nom = nom;
            this.vehiculeLoue = null;
        }


        public int getId() {
            return id;
        }

        public String getNom() {
            return nom;
        }

        public Vehicule getVehiculeLoue() {
            return vehiculeLoue;
        }

        public boolean louerVehicule(Vehicule vehicule) {
            if (vehicule.isDisponible() && this.vehiculeLoue == null) {
                this.vehiculeLoue = vehicule;
                vehicule.setDisponible(false);
                return true;
            }
            return false;
        }


        public void retournerVehicule() {
            if (this.vehiculeLoue != null) {
                this.vehiculeLoue.setDisponible(true);
                this.vehiculeLoue = null;
            }
        }

        public String toString() {
            String infoVehicule = (vehiculeLoue != null) ? vehiculeLoue.toString() : "Aucun véhicule loué";
            return "Client{" +
                    "id=" + id +
                    ", nom='" + nom + '\'' +
                    ", vehiculeLoue=" + infoVehicule +
                    '}';
        }
}

