package vehi;

import java.util.ArrayList;

public class GestionParc {
    private ArrayList<Vehicule> listeVehicules;
    private ArrayList<Client> listeClients;


    public GestionParc() {
        this.listeVehicules = new ArrayList<>();
        this.listeClients = new ArrayList<>();
    }

    public void ajouterVehicule(Vehicule vehicule) {
        listeVehicules.add(vehicule);
        System.out.println("Véhicule ajouté : " + vehicule);
    }

    public void ajouterClient(Client client) {
        listeClients.add(client);
        System.out.println("Client ajouté : " + client);
    }


    public boolean affecterVehiculeAClient(Client client, int vehiculeId) {
        Vehicule vehicule = null;

        // Trouver le véhicule par son ID
        for (Vehicule v : listeVehicules) {
            if (v.getId() == vehiculeId) {
                vehicule = v;
                break;  // Sortir de la boucle dès qu'on trouve le véhicule
            }
        }

        // Vérifier si le véhicule a été trouvé et s'il est disponible
        if (vehicule != null && vehicule.isDisponible()) {
            if (client.louerVehicule(vehicule)) {
                System.out.println("Véhicule " + vehiculeId + " loué à " + client.getNom());
                return true;
            } else {
                System.out.println("Le véhicule " + vehiculeId + " n'a pas pu être loué.");
            }
        } else {
            System.out.println("Véhicule " + vehiculeId + " non disponible ou inexistant.");
        }

        return false;
    }


    public void retournerVehicule(Client client) {
        client.retournerVehicule();
        System.out.println("Véhicule retourné par " + client.getNom());
    }

    public void afficherVehiculesDisponibles() {
        System.out.println("Véhicules disponibles :");
        for (Vehicule vehicule : listeVehicules) {
            if (vehicule.isDisponible()) {
                System.out.println(vehicule);
            }
        }
    }

    public void afficherClients() {
        System.out.println("Liste des clients :");
        for (Client client : listeClients) {
            System.out.println(client);
        }
    }
}

